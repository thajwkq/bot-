<?php
$token = "YOUR_BOT_TOKEN";
define('API_KEY', $token);
function bot($method, $datas = []) {
    $url = "https://api.telegram.org/bot" . API_KEY . "/" . $method;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $datas);
    $res = curl_exec($ch);
    curl_close($ch);
    return json_decode($res, true);
}
$update = json_decode(file_get_contents("php://input"), true);
$chat_id = $update["message"]["chat"]["id"];
$text = $update["message"]["text"];
if ($text == "/start") {
    bot("sendMessage", [
        "chat_id" => $chat_id,
        "text" => "اهلاً بك في بوت سيد الضلام 😈🔥",
    ]);
}
?>